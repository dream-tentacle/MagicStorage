# Art 当前版本素材

本目录只保留当前使用的素材和必要的生成文件。整理前的完整 Art 已备份至
`../Backups/Art-20261026-101122.zip`；旧版本、试验稿、过期对比图和中间缓存均可从该 ZIP 找回。

| 目录 | 内容 |
| --- | --- |
| [BuildingRefresh](BuildingRefresh/README.md) | 12 种建筑的当前 SVG/PNG、五种建筑的四方向源图、游戏分层导出与脚本 |
| [CosmicPrinter](CosmicPrinter/README.md) | 宇宙打印机当前 v5 PNG、PIL 源码和参数 |
| Conduits | 存储线图集及菜单图标的 SVG/PNG |
| Gizmos | 操作按钮 SVG、预览及导出脚本 |
| WorkbenchButtons | 工作台分类、收藏、置底等按钮 SVG 与导出脚本 |
| CoverConcepts | 最后一次确认的 v3 封面、文字区图层和位置参数 |
| Workshop | 中英文介绍图、分组长图、文案及当前生成脚本 |

宇宙工作台的左侧台钳部件已从当前源图、四方向图及游戏导出中删除。
游戏实际加载根目录 `Textures/`；Art 用于编辑和导出。

`current-assets.json` 列出所有当前文件、原始路径和 SHA-256，便于定位素材与核对。
