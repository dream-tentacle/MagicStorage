# 当前建筑素材

本目录是当前建筑贴图的统一入口。`*-refresh-v1.svg` 的名称沿用导出流程，
文件内容已包含后续修改；不要按名称中的 v1 将其误判为旧稿。

| 位置 | 用途 |
| --- | --- |
| 本目录的 12 组 SVG/PNG | 每种建筑的当前完整视图，也供 Workshop 介绍图使用 |
| `Directions/` | 存储单元、宇宙工作台、衣物适配器、物资补给器、宇宙培育器的四方向 SVG/PNG |
| `GameExport/*.svg` | 校准到游戏画布的 SVG；包含培育器完整图、底座、玻璃、顶盖 |
| `GameExport/Textures/` | 当前游戏 PNG 导出，保留透明边距与各层对齐 |
| `GameExport/References/` | 培育器四方向完整重组图 |
| `Inputs/` | 当前生成器仍使用的已确认底稿，按原文件名保留来源版本号 |

`Inputs/` 是生成依赖，不是供选用的历史方案。其他迭代底稿已收进 Art 完整备份。

宇宙工作台左侧台钳 `bench-vise` 已移除。SVG 和对应 PNG 均已同步。
存储线位于 `../Conduits/`；宇宙打印机位于 `../CosmicPrinter/`。

## 编辑与导出

直接修改当前 SVG 时，需同步完整视图、方向图、游戏 SVG 和对应 PNG。
已有 PNG 包含后续像素修整，整理过程保留了原有字节。

以下脚本分别负责不同阶段，按需要运行；全量重建会覆盖对应阶段的手工修改：

- `build_drafts.py`、`normalize_outlines.py`、`render_drafts.cjs`：从生成器及 Inputs 重建完整视图。
- `build_directions.py`、`render_directions.cjs`：重建四方向图。
- `prepare_game_exports.py`、`render_game_exports.cjs`：生成游戏画布 SVG 和 PNG。
- `install_game_exports.py`：生成培育器发光遮罩、安装到根目录 Textures，并同步游戏 XML 参数。
- `preview_outlines.py`、`preview_directions.py`、`preview_dense_layout.py`：按当前 PNG 生成检查图。
- `verify_outside_outline.cjs`：检查外围描边。

游戏导出以 256 像素/格为基准，画布边距 16 像素；普通建筑另向内留 12 像素。
培育器使用已确认的 90% 主体比例及对齐参数。不要用 Inputs 直接替换游戏贴图。
修改游戏 XML 后，按项目要求申请沙箱外权限运行根目录 `deploy.ps1`。
