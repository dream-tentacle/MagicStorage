# 宇宙打印机当前素材

- `build.py`：当前 PIL 绘图源代码。
- `CosmicPrinter-v5.png`：当前透明 PNG，544×544。
- `CosmicPrinter-preview.png`：同一版本的背景预览。
- `manifest.json`：颜色、画布、边距与游戏目标路径。

运行 `build.py` 会重建当前素材并写入根目录 Textures 中的打印机贴图。
打印机由 PIL 绘制，没有独立 SVG 源稿。
